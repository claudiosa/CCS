<?php

require '../../db.php';
require '../config.php';

header('Content-type: text/plain; encoding=utf-8');

echo '1.0' . "\n";

?>
