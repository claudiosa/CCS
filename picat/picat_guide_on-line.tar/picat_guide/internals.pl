# LaTeX2HTML 2008 (1.71)
# Associate internals original text with physical files.


$key = q/chapter:overview/;
$ref_files{$key} = "$dir".q|node4.html|; 
$noresave{$key} = "$nosave";

$key = q/section:Constraints/;
$ref_files{$key} = "$dir".q|node24.html|; 
$noresave{$key} = "$nosave";

$key = q/prebuiltmaps/;
$ref_files{$key} = "$dir".q|node34.html|; 
$noresave{$key} = "$nosave";

1;

