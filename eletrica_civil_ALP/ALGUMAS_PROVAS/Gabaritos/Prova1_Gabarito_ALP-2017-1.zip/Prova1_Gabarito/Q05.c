/*
Seja um valor inteiro positivo n, o qual indica que ser�o fornecidos n inteiros como entrada. Ao final, imprima o maior e o menor valor desta sequencia de valores.
   Exemplo:
   4
   27
   22
   21
   25

A sa�da ser� 21 (o menor) e 27 (o maior)
*/

#include <stdio.h>

int main(){
    int n, i, valor, maior, menor;

    printf("Digite a quantidade de valores que ser�o fornecidos: ");
    scanf("%d", &n);

    printf("Digite os valores: ");
    scanf("%d", &valor);

    maior = valor;
	menor = valor;	

    for(i = 1; i < n; i++){

        scanf("%d", &valor);

        if(valor > maior){ 
            maior = valor;
		}

        if(valor < menor){ 
            menor = valor;
		}
    }

    printf("O menor numero: %d\n", menor);
    printf("O maior numero: %d\n", maior);

    return 0;
}
