/*
   Fa�a um programa em C que fa�a os seguintes passos:
   (a) O usu�rio fornece um valor em metros (m)
   (b) O usu�rio escolhe uma unidade de medida para convers�o: centimetros (cm), milimetros (mm) ou milhas (mi)
   (c) Apresente o valor fornecido convertido para a unidade escolhida

   1000 mm = 100 cm = 1 m = 0.000625 mi

   DICA: usar switch-case
*/

#include <stdio.h>

int main(){
    float metros, resultado; 
    float opcao;  

    printf("Digite o valor em metros: ");
    scanf("%f", &metros);

    printf("Digite:\n 1 para converter para milimetros\n 2 para converter para centimetros ou\n 3 para converter para milhas\n");
    scanf("%d", &opcao);

    switch(opcao) {
	    case 1: 
			resultado = metros * 1000;
			printf("%f m = %f mm", metros, resultado);
			break;
	    case 2: 
			resultado = metros * 100;
			printf("%f m = %f cm", metros, resultado);
			break;
	    case 3: 
			resultado = metros * 0.000625;
			printf("%f m = %f mi", metros, resultado);
			break;
	    default:
			printf("Op��o invalida\n\n");
    }
    return 0;
}
