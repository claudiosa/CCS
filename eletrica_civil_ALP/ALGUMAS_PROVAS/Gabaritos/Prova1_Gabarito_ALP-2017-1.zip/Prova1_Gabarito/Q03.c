/*
   Fa�a um programa que calcule a serie abaixo:

   S = 1/n! - 2/(n-1)! + 3/(n-2)! - ... + n/1!
*/

#include <stdio.h>

int main(){
    float S = 0, fatorial;   
    int n, numerador, i;   

    printf("Digite a quantidade de termos: ");
    scanf("%d", &n);

    for(numerador = 1; numerador <= n; numerador++){
        fatorial = 1;
        for(i = n - numerador + 1; i > 0; i--){
            fatorial *= i;
	}

	if (numerador % 2 == 0){
		S -= numerador / fatorial;    	
	} else {        
		S += numerador / fatorial;    	
    }

    printf("S = %f\n", S);
    return 0;
}
