/*
Na empresa 'Gugou' os funcionarios recebem semanalmente por hora trabalhada. Voc� foi contratado para desenvolver um programa que calcula o sal�rio semanal a ser pago. Dados de entrada: QHT = quantidade de horas trabalhadas e VHT = valor da hora trabalhada. O sal�rio semanal � calculado de acordo com a tabela abaixo:

HORAS TRABALHADAS    |    VALOR PAGO
as primeiras 20h     |    valor da VHT base
as pr�ximas 20h      |    acr�scimo de 5% na VHT base
excedente            |    acr�scimo de 10% na VHT base
*/

#include <stdio.h>

int main(){
    float QHT, VHT; 
    float salarioSemanal;  

    printf("Digite a quantidade de horas trabalhadas: ");
    scanf("%f", &QHT);
    printf("Digite o valor da hora trabalhada: ");
    scanf("%f", &VHT);

    if(QHT <= 20){
        salarioSemanal = QHT * VHT;
    } else if(QHT <= 40) {
        salarioSemanal = 20 * VHT + (QHT - 20) * VHT * 1.05; 
    } else {
        salarioSemanal = 20 * VHT + 20 * VHT * 1.05 + (QHT - 40) * VHT * 1.1; 
    }

    printf("Salario semanal = %f", salarioSemanal);
    return 0;
}
