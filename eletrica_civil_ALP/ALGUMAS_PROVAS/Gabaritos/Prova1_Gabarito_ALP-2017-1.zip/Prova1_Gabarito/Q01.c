/*
   Fa�a um programa em C que, dados os valores para h (altura do tri�ngulo) e a (aresta do quadrado), calcule a �rea total da estrela (quadrado + 4 tri�ngulos)
*/

#include <stdio.h>

int main(){

    float a;   // aresta 
    float h;   // altura do triangulo 
    float areaTotal;  

    printf("Digite o valor da aresta a : ");
    scanf("%f", &a);
    
	printf("Digite o valor da altura do triangulo h : ");
    scanf("%f", &h);
    
	areaTotal = a*a + 4*(a*h/2.0); // quadrado + 4 tri�ngulos
    
	printf("A area total da estrela = %f", areaTotal);
    
	return 0;
}
